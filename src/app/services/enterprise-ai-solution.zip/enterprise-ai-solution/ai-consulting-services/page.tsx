import { Hero } from "./ai-consulting-services-components/Hero";
import NavigationClient from "@/components/navigation";
import LightContactSection from "@/components/LightContactSection";

import { StickyFooter as Footer } from "@/components/sticky-footer";
import BusinessChallenges from "./ai-consulting-services-components/business-challenges/BusinessChallenges";
import BusinessOutcomes from "./ai-consulting-services-components/BusinessOutcomes";

import CapabilitiesBentoGrid from "./ai-consulting-services-components/Core-capabilities/CapabilitiesBentoGrid";
import IndustriesShowcase from "@/components/IndustriesShowcase";
import WhyChooseWithTestimonialsSoftree from "./ai-consulting-services-components/WhySoftree/WhyChooseWithTestimonialsSoftree";
import { SuccessStories } from "./ai-consulting-services-components/SuccessStories";
import TrustedBrandsMarquee from "./ai-consulting-services-components/TrustedBrandsMarquee";
import AITechnologies from "./ai-consulting-services-components/AITechnologies";
import AIDeliveryProcess from "./ai-consulting-services-components/AIDeliveryProcess";
import { AiConsultingFaq } from "./ai-consulting-services-components/FAQ/AiConsultingFaq";


export const metadata = {
  title: "Enterprise AI Solutions | Softree Technology Pvt. Ltd.",
  description: "Enterprise AI Solutions That Deliver Measurable Business Outcomes. Automate workflows, build AI agents, and transform business operations.",
};

export default function EnterpriseAISolutionsPage() {
  return (
    <>
      <NavigationClient />
      <main className="bg-gradient-to-b from-zinc-50 via-white to-zinc-50">
        <Hero />
        <TrustedBrandsMarquee />
        <SuccessStories />
        <CapabilitiesBentoGrid />
        <BusinessChallenges />
        <BusinessOutcomes />
        <IndustriesShowcase />
        <AITechnologies />
        <AIDeliveryProcess />
        <div className="h-12 md:h-24"></div>
        <WhyChooseWithTestimonialsSoftree />

        <AiConsultingFaq />
        <LightContactSection />
        <Footer />
      </main>
    </>
  );
}
